import { redirect } from "next/navigation";

export default function AttendanceRedirectPage() {
  redirect("/dashboard/attendance");
}
