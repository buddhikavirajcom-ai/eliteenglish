declare module "bcryptjs";
